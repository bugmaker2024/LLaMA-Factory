from pymongo import MongoClient


client = MongoClient("mongodb://root:Vadd_Uaigc9468@10.60.173.241:27017/")
db = client["training"]
collection = db["metrics"]
collection.insert_one({"epoch": 1, "loss": 0.1, "task_id": "test_task_id"})
